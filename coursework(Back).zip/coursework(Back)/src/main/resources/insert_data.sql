insert into roles
values (1, 'Роль пользователя', 'USER'),
    (2, 'Роль библиотекаря', 'LIBRARIAN' )