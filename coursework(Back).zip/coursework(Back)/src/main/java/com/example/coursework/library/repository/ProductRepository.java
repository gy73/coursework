package com.example.coursework.library.repository;

import com.example.coursework.library.model.Product;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends GenericRepository<Product, Long>{

}
