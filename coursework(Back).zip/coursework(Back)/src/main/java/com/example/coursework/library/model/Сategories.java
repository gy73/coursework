package com.example.coursework.library.model;

public enum Сategories {
    TSHIRTS,

    PANTS,

    JACKETS
}