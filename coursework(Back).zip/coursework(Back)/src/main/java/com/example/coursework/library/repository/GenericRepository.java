package com.example.coursework.library.repository;

import com.example.coursework.library.model.GenericModel;
import com.example.coursework.library.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Optional;

@NoRepositoryBean
public interface GenericRepository <T extends GenericModel, L extends Number> extends JpaRepository<T, Long> {
    Optional<User> findUserByLogin(String login);
    Optional<User> findUserByEmail(String email);
}
