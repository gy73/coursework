package com.example.coursework.library.service;

import com.example.coursework.library.dto.RoleDTO;
import com.example.coursework.library.dto.UserDTO;
import com.example.coursework.library.mapper.GenericMapper;
import com.example.coursework.library.model.User;
import com.example.coursework.library.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserService extends GenericService<User, UserDTO> {

    private static final Long DEFAULT_ROLE_ID = 1L; // ID роли USER

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;

    public UserService(UserRepository userRepository,
                       GenericMapper<User, UserDTO> mapper,
                       BCryptPasswordEncoder bCryptPasswordEncoder) {
        super(userRepository, mapper);  // Теперь типы совместимы
        this.userRepository = userRepository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    @Override
    public UserDTO create(UserDTO newObject) {
        if (newObject == null) {
            throw new IllegalArgumentException("UserDTO cannot be null");
        }

        RoleDTO roleDTO = new RoleDTO();
        roleDTO.setId(DEFAULT_ROLE_ID);
        newObject.setRole(roleDTO);
        newObject.setPassword(bCryptPasswordEncoder.encode(newObject.getPassword()));
        newObject.setCreatedBy("REGISTRATION_FORM");
        newObject.setCreatedWhen(LocalDateTime.now());

        return mapper.toDTO(userRepository.save(mapper.toEntity(newObject)));
    }

    public Optional<UserDTO> getUserByLogin(final String login) {
        if (!StringUtils.hasText(login)) {
            return Optional.empty();
        }
        return userRepository.findUserByLogin(login)
                .map(mapper::toDTO);
    }

    public Optional<UserDTO> getUserByEmail(final String email) {
        if (!StringUtils.hasText(email)) {
            return Optional.empty();
        }
        return userRepository.findUserByEmail(email)
                .map(mapper::toDTO);
    }

    public boolean checkPassword(String password, UserDetails foundUser) {
        if (password == null || foundUser == null) {
            return false;
        }
        return bCryptPasswordEncoder.matches(password, foundUser.getPassword());
    }
}