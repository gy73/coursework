package com.example.coursework.library.constans;

public interface UserRolesConstans {
    public static final String USER = "USER";
    public static final String MODERATOR = "MODERATOR";
    public static final String ADMIN = "ADMIN";
}
