
export default function Button({title}){
  return(
    <a href="#" className='NavbarButtons'>{title}</a>
  )
}