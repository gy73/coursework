import ProductsCards from '../../components/Main/Products/ProductCards';

function Main() {
  return (
    <>
    <main className='main'>
      <div className='container'>
        <ProductsCards/>
      </div>
    </main>
    </>
  );
}
export default Main;