
export const products = [
    {   
        id: 1,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    },
    {   
        id: 2,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    },
        {
        id: 3,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    },
    {   id: 4,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    },
    {   
        id: 5,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    },
    {   id:6,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    },
    {   
        id: 7,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    },
    {   
        id: 8,
        designer: "Тимур Безбородников",
        description:'джинсы',
        image: "https://granhetl.com/static/itemsphoto/mini/1508_1_1730792200.jpeg",
        price: 5000
    }
]