export default function CategoryLink ({path, category}) {
        return (
        <>
        <li className="category">
                {category}
             </li>
        </>
    )
}